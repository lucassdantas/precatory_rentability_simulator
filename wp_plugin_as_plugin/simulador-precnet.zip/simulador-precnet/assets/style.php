<?php
?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Sora:wght@100..800&display=swap');

*{
    padding:0;
    margin:0;
    box-sizing:border-box;
    font-family:'sora', 'sans-serif';
}
:root{
    --buttonColor:#25D366;
    --buttonHover:#075E54;
    --darkGreen:#2D6218;
    --checkBoxGreen:#54AA54;
    --blue:#04265E;
    --borderBlue:#066CBB;
    
}
body{
    padding:24px;
    display:flex;
    justify-content:center;
}


.simulatorQuestionMarkIcon{
    width:20px;
    fill:#04265E;
}
.infoPopup{
    position:absolute;
    
    background-color:#FFF;
    box-shadow:0 0 2px rgba(0,0,0,.5);
    
    border-radius:25px;
    border:1px solid #444;
    
    padding:1.5em;
    width:90%;
    transition: opacity 0.5s ease, visibility 0.5s ease;
    
    opacity:0;
    visibility: hidden;
    z-index:2;
}
.rightCol .infoPopup{
  max-width:600px;
}
.simulatorVisible{
    opacity:1;
    visibility:visible;
}
.simulatorContainer {
    display: flex;
    flex-direction: column;
    align-items: center;
    overflow-x:hidden;
    color: #213E85;
    background: linear-gradient(to bottom , #FFF, #E5E5E5);
    border-radius: 25px;
    border:1px solid #E5E5E5;
    padding: 1em;
}

#simulatorContainer label{
    line-height:1;
    color:#213E85;
    
}
.simulatorHeader{

    padding:40px 32px 0;
    width:100%;
}
.simulatorTitleContainer{
    border-bottom:3px solid #54AA54;
    width:99.8%;
}
.simulatorTitle{
    font-size:40px;
    text-align:left;
    font-weight:700;
    margin-bottom:15px;
}

#simulatorContainer .simulatorBody{
    padding:20px;
    min-height:250px;
    height:100%;
    width:100%;
}

.precnetText{
    background-color: #213E85;
    border-radius: 45px;
    padding: 5px 5px;
    width:120px;
    min-width:120px;
    max-width:120px;
    text-align:center;
    font-weight: bold;
}


.lcilcaText{
    background-color: #90d55e;
    border-radius: 45px;
    padding: 5px;
    font-weight: bold;
    width:120px;
    min-width:120px;
    max-width:120px;
    text-align:center;

}
    
.lciLcaValue{
    margin-left: 10px;

}
.cdbText{
    background-color: #90d55e;
    border-radius: 45px;
    z-index: 1;
    padding: 5px;
    font-weight: bold;
    width:120px;
    min-width:120px;
    max-width:120px;
    text-align:center;
    
}

.cdbValue{
    margin-left: 10px;
}
   

.precnetValue{
    margin-left: 10px;
}


#simulatorContainer .hidden{
    display:none!important;
    visibility:hidden;
    
}

#simulatorContainer .disabled, #simulatorContainer .disabled div{
  color:#000!important;
  border:1px solid #222!important;
}
#simulatorContainer .disabled label{
  color:#000!important;
}
#simulatorContainer .disabled input[type="radio"] + label::before,
#simulatorContainer .disabled input[type="checkbox"] + label::before {
   background-color: #999;
   border: 1px solid #eee;
}
#simulatorContainer .paymentMonth{
    height:184px;
    min-height:fit-content;
}

#simulatorContainer input[type='radio']{
    width:16px;
}
#simulatorContainer .row{
    display:flex;
    margin:0 0 0 0;
}

#simulatorContainer .col{
    flex-direction:column;
    padding:12px 12px 0;
}

#simulatorContainer .col50{
    width:50%;
}

#simulatorContainer .col100{
    width:100%;
}

#simulatorContainer .monthListContainer{
    width:100%;
    display:flex;
}
#simulatorContainer .monthList{
    width:92%;
    display:flex;
    justify-content:space-between;
    margin:5px 0;
}

#simulatorContainer .topMonthList{
    text-align:left;
    justify-content:flex-start;
}
#simulatorContainer .bottomMonthList{
    text-align:right;
    justify-content:flex-end;
}
#simulatorContainer .topMonthList span{
    margin-right:0;
}
#simulatorContainer .bottomMonthList span{
    margin-left:0;
}
#simulatorContainer .rightCol{
    display:flex;
}

.monthPaymentAndList{
    border: 1.5px solid #90d55e;
    border-radius: 10px;
    padding: 3% 35px;
    width: 100%;
 
}

#simulatorContainer .userInputData{
    margin-bottom:28px;
    display:flex;
    flex-direction:column;
}
#simulatorContainer .userInputData label{
    margin-right:12px;
}
#simulatorContainer .inputIdentifier{
    margin-right:8px;
    margin-bottom:10px;
    font-weight:700;
    font-size:24px;
}
#simulatorContainer .chartContainer{
    
    height:184px;
    margin-top:24px;
}


#simulatorContainer .chart {
    color:#fff;
    border: 1.5px solid #90d55e;
    border-radius: 10px;
    padding: 1.5%;
    
}
#simulatorContainer .warningChart {
    color:#000;
    padding:1em;
}


#simulatorContainer .amountInvestedContainer{
    border: 1.5px solid #90d55e;
    border-radius: 10px;
    padding: 25px 15px;
    width:93%;

}
#simulatorContainer .moneySimbolAndAmountInvestedInputContainer{
    border-bottom: 3px solid #54AA54;
}

.bar {
    display:flex;
    align-items:center;
    width:fit-content;
    height: 100%;
    flex-grow: 1;
    transition: width 0.5s ease;
    margin: 12px 0;
    border-radius: 20px;
    position: relative;
    background-color: rgba(0, 0, 0, 0.1); /* Adicionando um tom de cinza claro */
    overflow: hidden; /* Para ocultar o texto que se estende além da barra */
}

.bar .value {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: #333; /* Mudando a cor do texto para um tom mais escuro */
    font-size: 12px; /* Ajustando o tamanho da fonte */
    font-weight: bold; /* Deixando o texto em negrito */
    white-space: nowrap; /* Impedindo que o texto quebre em várias linhas */
    padding: 2px 6px; /* Adicionando um espaçamento interno */
    background-color: rgba(255, 255, 255, 0.8); /* Adicionando um fundo branco translúcido */
    border-radius: 10px; /* Arredondando as bordas do texto */
}

.quotaInformationContainer{
    text-align:center;
    margin-top:0px;
    padding:0 80px;
    width:100%;
}
#simulatorContainer .informationSimbol{
    color:#0495EC;
    font-size:12px;
}
#simulatorContainer .information{
    font-size:12px;
    font-weight:400;
}
#precnet {
    height: 30px;
    background-color: #7B90B6;
}

#cdb {
    
    height: 30px;
    background-color: #9EC99E;
}

#lci-lca {
    
    height: 30px;
    background-color: #9EC99E;
}

#simulatorContainer .chartQuotaValue{
    white-space:nowrap;
    font-size:22px;
}
#simulatorContainer #moneySimbol{
    font-size:28px;
    font-weight:700;
}
#amountInvested{
    border:unset;
    color: #213E85;
    background-color: unset;
    padding:6px 12px;
    outline: none;
    font-size:28px;
    width:85%;
}


#simulatorContainer .inputAndLabelContainer{
    border: 2px solid #213E85;
    border-radius: 50px;
    padding: 7px 10px;
    margin-right: 25px;
    display:flex;
    flex-wrap:nowrap;
}

.inputAndLabelContainerSelected{

    border: 1px solid #54AA54;
    
}

#simulatorContainer .validityYear .inputAndLabelContainer{
    width:30%;
    display:flex;
    margin-right:35px;
    justify-content:center;
    align-items:center;
    text-align:center;
}
#simulatorContainer .quotaType .inputAndLabelContainer{
    width:45%;
    display:flex;
    margin-right:35px;
    justify-content:center;
    align-items:center;
    text-align:center;
}
#simulatorContainer .inputAndLabelContainer label{
    text-align:center;
    font-size:20px;
}

#simulatorContainer .inputAndLabelContainer input{
    margin-right:5px;
}


#simulatorContainer .inputContainer{
    display:flex;
}
#simulatorContainer .instructionContainer{
    width:100%;
    margin-top:24px;
}
#simulatorContainer .monthContainer span{
  font-weight:700;

}
#simulatorContainer .monthContainer{
    margin-bottom:12px;
    display:flex;
    flex-direction:column;
}
#simulatorContainer .selectedMonthContainer{
    display:none;
    visibility:hidden;
}

#simulatorContainer .validityYearText{
    font-size:16px;
    font-weight:400;
    color:#54AA54;
}

#simulatorContainer .selected {
    border: 2px solid #54AA54;
}

#simulatorContainer .textGreen{
    color: #54AA54;
}

#simulatorContainer .bold {
    font-weight: bold;
}

#simulatorContainer input[type="range"] {
    /* Remove estilos padrão */
    -webkit-appearance: none;
    -moz-apperance: none;
    appearance: none;
    background-color: #213E85; /* Cor de fundo cinza */
    border-radius: 10px;
    /* Thumb (alça) */
    cursor: pointer;
  }

#simulatorContainer input[type="range"]::-webkit-slider-thumb {
    -webkit-appearance: none;
    appearance: none;
    /* Dimensões e layout */

    background-color: #04265E; /* Cor da bola */
    border-radius: 50%; /* Forma circular */
}

#simulatorContainer input[type="range"]::-moz-range-thumb {
    -moz-appearance: none;
    appearance: none;
    /* Dimensões e layout */

    background-color: #04265E; /* Cor da bola */
    border-radius: 50%; /* Forma circular */
}

#monthOfPayment{
    width: 100%;
    height: 5px;
    margin-top:12px;
    
}

#monthOfPayment::-webkit-slider-thumb{
    background: #54AA54!important;
    box-shadow: 0 0 10px 3px  #54AA54;
    height: 15px;
    width: 15px;
}
#simulatorContainer .monthOfPaymentTitle{
    margin-bottom:0px;
}

#simulatorContainer input[type="radio"],
#simulatorContainer input[type="checkbox"] {
    position: absolute;
    left: -999em;
}

#simulatorContainer input[type="radio"] + label,
#simulatorContainer input[type="checkbox"] + label {
    position: relative;
    overflow: hidden;
    cursor: pointer;
}

#simulatorContainer input[type="radio"] + label::before,
#simulatorContainer input[type="checkbox"] + label::before {
   content: "";
   display: inline-block;
   vertical-align: -20%;
   height: 2ex;
   width: 2ex;
   background-color: white;
   border: 1px solid #213E85;
   border-radius: 4px;
   box-shadow: inset 0 2px 5px rgba(0,0,0,0.25);
   margin-right: 0.5em;
}

#simulatorContainer input[type="radio"]:checked + label::before {
   background: radial-gradient(circle at center, #54AA54 .9ex, #fff 1ex);
}

#simulatorContainer input[type="radio"] + label::before {
   border-radius: 50%;
}

#simulatorContainer input[type="checkbox"]:checked + label::after {
   content: '';
   position: absolute;
   width: 1.2ex;
   height: 0.4ex;
   background: rgba(0, 0, 0, 0);
   top: 0.9ex;
   left: 0.4ex;
   border: 3px solid #1062a4;
   border-top: none;
   border-right: none;
   -webkit-transform: rotate(-45deg);
   -moz-transform: rotate(-45deg);
   -o-transform: rotate(-45deg);
   -ms-transform: rotate(-45deg);
   transform: rotate(-45deg);
}

@media(max-width:1045px){
    #simulatorContainer .row{
        flex-direction:column;
    }

    #simulatorContainer .col{
        width:100%;
    }

    #simulatorContainer .inputAndLabelContainer{
        margin-bottom:12px;
    }
    #simulatorContainer .validityYear .inputAndLabelContainer{
        max-width:150px;
        width:100%;
    }
    #simulatorContainer .quotaType .inputAndLabelContainer{
        max-width:250px;
        width:100%;

    }
    #simulatorContainer .chartQuotaValue{
        font-size:18px;
    }
    #simulatorContainer .paymentMonth{
        height:fit-content;
    }
}

@media(max-width:768px){
    #simulatorContainer .chartQuotaValue{
        font-size:16px;
    }
}

@media(max-width:667px){
    .simulatorContainer{
        padding:0.2em;
    }
    #simulatorContainer .simulatorHeader{
        padding:20px 22px 0;
    }
    #simulatorContainer .simulatorTitle{
        font-size:20px;
    }
    #simulatorContainer .simulatorBody{
        padding:10px;
    }

    #simulatorContainer .validityYear .inputAndLabelContainer{
        max-width:100px;    
        margin-right:12px;
    }
    #simulatorContainer .quotaTypeInputContainer .inputAndLabelContainer{
        max-width:160px;   
        margin-right:12px;     
    }
    #simulatorContainer .validityYearText{
        display:block;
    }
    #simulatorContainer #moneySimbol{
        font-size:16px;
    }
    #simulatorContainer #amountInvested{
        width:84%;
        font-size:18px;
    }
    #simulatorContainer .monthRowContainer{
        display:flex;
        align-items:center;
        justify-content:space-between;
    }
    #simulatorContainer .monthContainer{
        width:80%;
    }
    #simulatorContainer .monthList{
        font-size:8px;
        color:#213E85;
        display:none;
        visibility:hidden;
    }
    #simulatorContainer .selectedMonthContainer{
        display:inline-block;
        visibility:visible;
    }
    #simulatorContainer #selectedMonth{
        color:#90d55e;
        font-weight:bold;
    }
    #simulatorContainer .monthOfPaymentTitle{
        font-size:16px;
    }
    #simulatorContainer .inputIdentifier{
        font-size:16px;
    }
    #simulatorContainer .rentabilityTitle{
        font-size:18px;
    }
    #simulatorContainer .quotaInformationContainer{
        padding:0;
    }
    #simulatorContainer .precnetText, #simulatorContainer .cdbText, #simulatorContainer .lcilcaText{
        width:95px;
        min-width:95px;
        max-width:95px;
        padding:2% 0;
    }
    #simulatorContainer .chart{
        font-size:14px;
    }
    #simulatorCOntainer .chartQuotaValue{
        font-size:12px;
    }
    #simulatorContainer .chart #precnet{
        width:100%!important;
    }
    #simulatorContainer .chart .bar{
        width:97%!important;
    }
    #simulatorContainer .chart .bar{
        width:97%!important;
    }
    #simulatorContainer .amountInvestedContainer{
        padding:3% 35px;
    }
    #simulatorContainer .col{
        padding:5px 12px;
    }
    #simulatorContainer .chartContainer{
        height:fit-content;
    }
    #simulatorContainer .inputAndLabelContainer label{
        font-size:14px;
    }
    #simulatorContainer .userInputData {
        margin-bottom:5px;
    }
    
}

@media(max-width:430px){
    #simulatorContainer .inputAndLabelContainer label{
        font-size:10px;
    }
}
@media(max-width:356px){
    .simulatorContainer{
        padding:2px;
    }
    #simulatorContainer .simulatorHeader{
        padding:15px 10px 0;
    }
    #simulatorContainer .simulatorBody{
        padding:0px;
    }
    #simulatorContainer #moneySimbol{
        font-size:16px;
    }
    #simulatorContainer #amountInvested{
        width:80%;
        font-size:16px;
    }
    #simulatorContainer .quotaInformationContainer{
        padding:15px 5px;
    }
    #simulatorContainer .validityYear .inputAndLabelContainer, #simulatorContainer .quotaType .inputAndLabelContainer{
        width:100%;
        max-width:100%;
        margin-right:0;
    }
    #simulatorContainer .chartQuotaValue{
        font-size:10px;
    }
    #simulatorContainer .inputContainer{
        flex-direction:column;
    }
    #simulatorContainer .amountInvestedContainer{
        padding:15px;
    }
    #simulatorContainer .infoPopup{
        font-size:12px;
    }
}
</style>
<?php